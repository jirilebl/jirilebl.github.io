#!/bin/sh
for n in 8 9 10 ; do
	./sketch2pdf.sh diag"$n"
done
